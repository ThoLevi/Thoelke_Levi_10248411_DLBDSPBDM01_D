﻿-- =====================================================================
--  Buchverleih / Buchtausch-App – Beispieldaten (10 Datensätze je Tabelle)
--  DBMS: Microsoft SQL Server (T-SQL), ausführbar in SQL Server Management Studio
--  Voraussetzung: buecher_ausleihe_db_mssql.sql wurde zuvor ausgeführt
--  (frisch angelegte Datenbank, IDENTITY-Werte beginnen bei 1).
--  Die Reihenfolge der INSERTs folgt den Fremdschlüsseln.
-- =====================================================================
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

USE buecher_ausleihe_db;
GO

-- ============================================================
-- TABELLE: Ort
-- ============================================================
INSERT INTO Ort (Postleitzahl, Stadt, Land) VALUES
    (N'80804', N'München', 'DE'),
    (N'80337', N'München', 'DE'),
    (N'81669', N'München', 'DE'),
    (N'80637', N'München', 'DE'),
    (N'80687', N'München', 'DE'),
    (N'80797', N'München', 'DE'),
    (N'81541', N'München', 'DE'),
    (N'81673', N'München', 'DE'),
    (N'81677', N'München', 'DE'),
    (N'81369', N'München', 'DE');
GO

-- ============================================================
-- TABELLE: Adresse
-- Koordinaten (WGS 84) liegen im Münchner Stadtgebiet, damit die
-- ============================================================
INSERT INTO Adresse (OrtID, Strasse, Hausnummer, Breitengrad, Laengengrad) VALUES
    (1,  N'Leopoldstraße',        N'137', 48.170200, 11.586500),
    (2,  N'Lindwurmstraße',       N'84',  48.126300, 11.553900),
    (3,  N'Rosenheimer Straße',   N'152', 48.121000, 11.607000),
    (4,  N'Dachauer Straße',      N'237', 48.165800, 11.531000),
    (5,  N'Landsberger Straße',   N'184', 48.141800, 11.514500),
    (6,  N'Schleißheimer Straße', N'219', 48.166000, 11.566000),
    (7,  N'Balanstraße',          N'96',  48.115300, 11.590000),
    (8,  N'Kreillerstraße',       N'63',  48.128500, 11.634000),
    (9,  N'Prinzregentenstraße',  N'118', 48.141500, 11.613000),
    (10, N'Plinganserstraße',     N'74',  48.113500, 11.537000);
GO

-- ============================================================
-- TABELLE: Benutzer
-- Max Mustermann und Anna Schmidt sind Administratoren.
-- ============================================================
INSERT INTO Benutzer (Name, Email, Telefonnummer, AdresseID, IsAdmin, RegistriertAm) VALUES
    (N'Max Mustermann', N'max.mustermann@mail.com', N'0151 23456781', 1,  1, '2026-01-10 09:15:00'),
    (N'Anna Schmidt',   N'anna.schmidt@mail.com',   N'0152 34567812', 2,  1, '2026-01-12 18:40:00'),
    (N'Lukas Müller',   N'lukas.mueller@mail.com',  NULL,             3,  0, '2026-02-03 20:05:00'),
    (N'Laura Fischer',  N'laura.fischer@mail.com',  N'0160 45678123', 4,  0, '2026-02-17 11:30:00'),
    (N'Jonas Weber',    N'jonas.weber@mail.com',    N'0170 56781234', 5,  0, '2026-03-02 14:22:00'),
    (N'Sophie Wagner',  N'sophie.wagner@mail.com',  NULL,             6,  0, '2026-03-25 08:50:00'),
    (N'Felix Becker',   N'felix.becker@mail.com',   N'0171 67812345', 7,  0, '2026-04-11 19:10:00'),
    (N'Marie Hoffmann', N'marie.hoffmann@mail.com', N'0176 78123456', 8,  0, '2026-05-06 16:45:00'),
    (N'Tim Schäfer',    N'tim.schaefer@mail.com',   NULL,             9,  0, '2026-06-19 21:00:00'),
    (N'Lea Koch',       N'lea.koch@mail.com',       N'0157 81234567', 10, 0, '2026-07-08 10:05:00');
GO

-- ============================================================
-- TABELLE: Genre
-- ============================================================
INSERT INTO Genre (Name) VALUES
    (N'Roman'),
    (N'Kurzgeschichte'),
    (N'Lyrik'),
    (N'Drama'),
    (N'Biografie'),
    (N'Sachbuch'),
    (N'Krimi'),
    (N'Fantasy'),
    (N'Science-Fiction'),
    (N'Novelle');
GO

-- ============================================================
-- TABELLE: Verlag
-- ============================================================
INSERT INTO Verlag (Name) VALUES
    (N'Penguin Verlag'),
    (N'Rowohlt Verlag'),
    (N'Suhrkamp Verlag'),
    (N'Carlsen Verlag'),
    (N'S. Fischer Verlag'),
    (N'dtv'),
    (N'Kiepenheuer & Witsch'),
    (N'Reclam'),
    (N'Piper Verlag'),
    (N'Steidl Verlag');
GO

-- ============================================================
-- TABELLE: Sprache
-- ============================================================
INSERT INTO Sprache (Name) VALUES
    (N'Deutsch'),
    (N'Englisch'),
    (N'Französisch'),
    (N'Spanisch'),
    (N'Italienisch'),
    (N'Portugiesisch'),
    (N'Niederländisch'),
    (N'Polnisch'),
    (N'Japanisch'),
    (N'Chinesisch');
GO

-- ============================================================
-- TABELLE: Autor
-- ============================================================
INSERT INTO Autor (Name) VALUES
    (N'Johann Wolfgang von Goethe'),
    (N'Friedrich Schiller'),
    (N'Thomas Mann'),
    (N'Bertolt Brecht'),
    (N'Franz Kafka'),
    (N'Heinrich Böll'),
    (N'Christa Wolf'),
    (N'Günter Grass'),
    (N'Stefan Zweig'),
    (N'Ingeborg Bachmann');
GO

-- ============================================================
-- TABELLE: Buch
-- Spalten: Titel, VerlagID, GenreID, SpracheID, Erscheinungsjahr
-- ============================================================
INSERT INTO Buch (Titel, VerlagID, GenreID, SpracheID, Erscheinungsjahr) VALUES
    (N'Faust. Der Tragödie erster Teil', 8,  4,  1, 1808),
    (N'Die Räuber',                      8,  4,  1, 1781),
    (N'Buddenbrooks',                    5,  1,  1, 1901),
    (N'Die Dreigroschenoper',            3,  4,  1, 1928),
    (N'The Trial',                       1,  1,  2, 1937),
    (N'Ansichten eines Clowns',          7,  1,  1, 1963),
    (N'Kassandra',                       3,  2,  1, 1983),
    (N'Die Blechtrommel',                10, 1,  1, 1959),
    (N'Schachnovelle',                   5,  10, 1, 1942),
    (N'Malina',                          3,  1,  1, 1971);
GO

-- ============================================================
-- TABELLE: BuchAutor (n:m Buch – Autor)
-- ============================================================
INSERT INTO BuchAutor (BuchID, AutorID) VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5),
    (6, 6),
    (7, 7),
    (8, 8),
    (9, 9),
    (10, 10);
GO

-- ============================================================
-- TABELLE: Buchbewertung
-- Jeder Benutzer bewertet ein Buch höchstens einmal.
-- ============================================================
INSERT INTO Buchbewertung (BenutzerID, BuchID, Sterne, Datum) VALUES
    (1,  3,  5, '2026-03-14'),
    (2,  7,  4, '2026-04-02'),
    (3,  1,  3, '2026-04-20'),
    (4,  9,  5, '2026-05-11'),
    (5,  4,  2, '2026-05-30'),
    (6,  10, 4, '2026-06-15'),
    (7,  2,  5, '2026-07-01'),
    (8,  6,  3, '2026-07-22'),
    (9,  8,  4, '2026-08-09'),
    (10, 5,  1, '2026-09-03');
GO

-- ============================================================
-- TABELLE: Exemplar
-- Exemplar n gehört Benutzer n und ist ein Exemplar von Buch n.
-- ============================================================
INSERT INTO Exemplar (BuchID, BesitzerID, Zustand, IstAusleihbar) VALUES
    (1,  1,  N'sehr gut',        1),
    (2,  2,  N'gut',             1),
    (3,  3,  N'gebraucht',       1),
    (4,  4,  N'neu',             1),
    (5,  5,  N'stark gebraucht', 1),
    (6,  6,  N'gut',             1),
    (7,  7,  N'sehr gut',        1),
    (8,  8,  N'gebraucht',       1),
    (9,  9,  N'neu',             1),
    (10, 10, N'gut',             0);
GO

-- ============================================================
-- TABELLE: Versandoption
-- ============================================================
INSERT INTO Versandoption (Anbieter, Bezeichnung, Preis, LieferzeitTage) VALUES
    (N'DHL',           N'Päckchen S',             3.99, 2),
    (N'DHL',           N'Paket bis 2 kg',         5.49, 2),
    (N'Hermes',        N'Päckchen',               3.79, 3),
    (N'Hermes',        N'Paket S',                4.50, 3),
    (N'DPD',           N'Paket XS',               4.40, 2),
    (N'GLS',           N'Paket S',                4.29, 2),
    (N'Deutsche Post', N'Büchersendung',          1.95, 4),
    (N'Deutsche Post', N'Warensendung',           2.70, 4),
    (N'UPS',           N'Standard',               7.90, 2),
    (N'DHL',           N'Express',               14.90, 1);
GO

-- ============================================================
-- TABELLE: Abholort
-- Jeder Benutzer bietet einen Abholort an seiner Adresse an.
-- ============================================================
INSERT INTO Abholort (BenutzerID, AdresseID, Bezeichnung, Hinweis) VALUES
    (1,  1,  N'Hauseingang Leopoldstraße',   N'Bitte bei Mustermann klingeln'),
    (2,  2,  N'Wohnung Lindwurmstraße',      N'3. Stock, kein Aufzug'),
    (3,  3,  N'Innenhof Rosenheimer Straße', NULL),
    (4,  4,  N'Hauseingang Dachauer Straße', N'Hintereingang benutzen'),
    (5,  5,  N'Laden im Erdgeschoss',        N'Abgabe auch beim Nachbarn möglich'),
    (6,  6,  N'Hauseingang Schleißheimer Straße', NULL),
    (7,  7,  N'Wohnung Balanstraße',         N'Bitte vorher kurz anrufen'),
    (8,  8,  N'Hauseingang Kreillerstraße',  NULL),
    (9,  9,  N'Pförtner Prinzregentenstraße', N'Abholung nur werktags'),
    (10, 10, N'Hauseingang Plinganserstraße', NULL);
GO

-- ============================================================
-- TABELLE: Zeitslot
-- Slots 1–6: Abholung, Slots 7–10: Rückgabe (jeweils am Abholort
-- des Besitzers).
-- ============================================================
INSERT INTO Zeitslot (AbholortID, Beginn, Ende) VALUES
    (1, '2026-08-03 17:00:00', '2026-08-03 18:00:00'),
    (2, '2026-08-20 18:00:00', '2026-08-20 19:00:00'),
    (3, '2026-09-01 17:30:00', '2026-09-01 18:30:00'),
    (4, '2026-09-28 16:00:00', '2026-09-28 17:00:00'),
    (5, '2026-10-05 18:00:00', '2026-10-05 19:00:00'),
    (6, '2026-10-16 17:00:00', '2026-10-16 18:00:00'),
    (1, '2026-08-16 10:00:00', '2026-08-16 11:00:00'),
    (2, '2026-09-09 18:00:00', '2026-09-09 19:00:00'),
    (3, '2026-09-15 17:30:00', '2026-09-15 18:30:00'),
    (4, '2026-10-28 16:00:00', '2026-10-28 17:00:00');
GO

-- ============================================================
-- TABELLE: Ausleihe
-- Ausleihen 1–6: Abholung über Zeitslots, 7–10: Versand.
-- Der Verleiher ist jeweils der Besitzer des Exemplars.
-- ============================================================
INSERT INTO Ausleihe
    (AusleiherID, ExemplarID, AngefragtAm, Startdatum, GeplantesRueckgabedatum, TatsaechlichesRueckgabedatum,
     Status, Uebergabeart, AbholZeitslotID, RueckgabeZeitslotID, VersandoptionID, Sendungsnummer)
VALUES
    (2,  1,  '2026-07-30 12:10:00', '2026-08-03', '2026-08-17', '2026-08-16', N'zurueckgegeben', N'Abholung', 1,    7,    NULL, NULL),
    (3,  2,  '2026-08-17 19:45:00', '2026-08-20', '2026-09-10', '2026-09-09', N'zurueckgegeben', N'Abholung', 2,    8,    NULL, NULL),
    (4,  3,  '2026-08-28 08:30:00', '2026-09-01', '2026-09-15', '2026-09-15', N'zurueckgegeben', N'Abholung', 3,    9,    NULL, NULL),
    (5,  4,  '2026-09-24 21:05:00', '2026-09-28', '2026-10-28', NULL,         N'ausgeliehen',    N'Abholung', 4,    10,   NULL, NULL),
    (6,  5,  '2026-10-01 15:20:00', '2026-10-05', '2026-10-19', NULL,         N'ausgeliehen',    N'Abholung', 5,    NULL, NULL, NULL),
    (7,  6,  '2026-10-11 10:00:00', '2026-10-16', '2026-10-30', NULL,         N'bestaetigt',     N'Abholung', 6,    NULL, NULL, NULL),
    (8,  7,  '2026-07-05 17:35:00', '2026-07-10', '2026-07-31', '2026-07-30', N'zurueckgegeben', N'Versand',  NULL, NULL, 1,    N'00340434161094042557'),
    (9,  8,  '2026-09-27 09:50:00', '2026-10-01', '2026-10-22', NULL,         N'ausgeliehen',    N'Versand',  NULL, NULL, 3,    N'H1002345678901'),
    (10, 9,  '2026-10-12 20:15:00', '2026-10-20', '2026-11-10', NULL,         N'angefragt',      N'Versand',  NULL, NULL, 7,    NULL),
    (1,  10, '2026-09-10 13:00:00', '2026-09-15', '2026-09-29', NULL,         N'abgelehnt',      N'Versand',  NULL, NULL, 2,    NULL);
GO

-- ============================================================
-- TABELLE: Verlaengerungsanfrage
-- Das neue Rückgabedatum liegt jeweils nach dem geplanten.
-- ============================================================
INSERT INTO Verlaengerungsanfrage (AusleiheID, BeantragtAm, NeuesRueckgabedatum, Status) VALUES
    (1, '2026-08-12 18:00:00', '2026-08-24', N'abgelehnt'),
    (2, '2026-09-05 20:30:00', '2026-09-17', N'angenommen'),
    (3, '2026-09-10 07:45:00', '2026-09-29', N'abgelehnt'),
    (4, '2026-10-12 19:15:00', '2026-11-04', N'offen'),
    (4, '2026-10-01 11:00:00', '2026-11-11', N'abgelehnt'),
    (5, '2026-10-09 16:40:00', '2026-10-26', N'angenommen'),
    (5, '2026-10-13 08:20:00', '2026-11-02', N'offen'),
    (6, '2026-10-12 12:00:00', '2026-11-06', N'offen'),
    (7, '2026-07-25 21:10:00', '2026-08-07', N'abgelehnt'),
    (8, '2026-10-13 09:05:00', '2026-10-29', N'offen');
GO

-- ============================================================
-- TABELLE: Benutzerbewertung (ternär: Bewerter × Bewerteter × Ausleihe)
-- Ausleiher und Verleiher bewerten sich nach der Ausleihe gegenseitig.
-- ============================================================
INSERT INTO Benutzerbewertung (BewerterID, BewerteterID, AusleiheID, Sterne, Kommentar, Datum) VALUES
    (2, 1, 1, 5, N'Sehr freundlich, Buch war wie beschrieben.',           '2026-08-16'),
    (1, 2, 1, 5, N'Pünktlich und sorgfältig zurückgegeben.',              '2026-08-17'),
    (3, 2, 2, 4, N'Unkomplizierte Übergabe.',                             '2026-09-09'),
    (2, 3, 2, 4, N'Alles bestens, gerne wieder.',                         '2026-09-10'),
    (4, 3, 3, 3, N'Zustand etwas schlechter als angegeben.',              '2026-09-15'),
    (3, 4, 3, 5, N'Sehr zuverlässig.',                                    '2026-09-16'),
    (8, 7, 7, 5, N'Schnell verschickt und gut verpackt.',                 '2026-07-30'),
    (7, 8, 7, 4, N'Rücksendung kam einen Tag früher als geplant.',        '2026-07-31'),
    (5, 4, 4, 5, N'Nette Übergabe, Buch ist wirklich neu.',               '2026-09-29'),
    (9, 8, 8, 4, NULL,                                                    '2026-10-03');
GO

-- ============================================================
-- TABELLE: Regel
-- ============================================================
INSERT INTO Regel (Bezeichnung, Beschreibung) VALUES
    (N'Respektvoller Umgang',      N'Beleidigungen, Drohungen und Diskriminierung sind nicht erlaubt.'),
    (N'Pünktliche Rückgabe',       N'Ausgeliehene Bücher werden spätestens zum vereinbarten Datum zurückgegeben.'),
    (N'Ehrliche Zustandsangabe',   N'Der Zustand eines Exemplars wird wahrheitsgemäß angegeben.'),
    (N'Keine kommerzielle Nutzung',N'Die Plattform dient nicht dem gewerblichen Verkauf oder Verleih.'),
    (N'Termine einhalten',         N'Gebuchte Zeitslots werden wahrgenommen oder rechtzeitig abgesagt.'),
    (N'Kein Spam',                 N'Massennachrichten und Werbung sind untersagt.'),
    (N'Keine verbotenen Inhalte',  N'Es werden keine rechtswidrigen Inhalte angeboten oder geteilt.'),
    (N'Sorgfältiger Umgang',       N'Ausgeliehene Bücher werden pfleglich behandelt.'),
    (N'Ehrliche Bewertungen',      N'Bewertungen geben die tatsächliche Erfahrung wieder.'),
    (N'Ein Konto pro Person',      N'Jede Person darf nur ein Benutzerkonto besitzen.');
GO

-- ============================================================
-- TABELLE: Meldung (ternär: Melder × Gemeldeter × Regel)
-- ============================================================
INSERT INTO Meldung (MelderID, GemeldeterID, RegelID, Beschreibung, GemeldetAm, Status) VALUES
    (4,  3,  3, N'Exemplar hatte mehr Gebrauchsspuren als angegeben.',       '2026-09-15 20:00:00', N'geprueft'),
    (6,  9,  1, N'Unfreundliche Nachricht nach Absage.',                     '2026-06-25 18:30:00', N'geprueft'),
    (7,  10, 5, N'Zum vereinbarten Zeitslot nicht erschienen.',              '2026-07-14 19:10:00', N'geprueft'),
    (3,  5,  6, N'Mehrfach Werbenachrichten erhalten.',                      '2026-08-02 09:45:00', N'geprueft'),
    (8,  6,  2, N'Rückgabe erst nach mehrfacher Erinnerung.',                '2026-08-21 12:00:00', N'verworfen'),
    (10, 4,  4, N'Bietet offenbar Bücher gegen Bezahlung an.',               '2026-09-05 22:15:00', N'geprueft'),
    (9,  7,  9, N'Bewertung entspricht nicht dem tatsächlichen Ablauf.',     '2026-09-18 14:20:00', N'verworfen'),
    (5,  8,  8, N'Buchrücken nach Ausleihe beschädigt.',                     '2026-10-02 17:05:00', N'offen'),
    (2,  10, 5, N'Erneut einen Abholtermin verpasst.',                       '2026-10-08 18:40:00', N'offen'),
    (1,  5,  10, N'Verdacht auf Zweitkonto mit gleicher Adresse.',           '2026-10-12 08:30:00', N'offen');
GO

-- ============================================================
-- TABELLE: Sanktion (ternär: Admin × Benutzer × Regel)
-- Sanktionen verhängen nur die Admins Max Mustermann (1) und Anna Schmidt (2).
-- ============================================================
INSERT INTO Sanktion (AdminID, BenutzerID, RegelID, Art, Beginn, Ende, Begruendung) VALUES
    (1, 3,  3,  N'Verwarnung', '2026-09-16 10:00:00', NULL,                  N'Zustand eines Exemplars falsch angegeben.'),
    (2, 9,  1,  N'Verwarnung', '2026-06-26 09:00:00', NULL,                  N'Unfreundliche Nachricht an andere Person.'),
    (1, 10, 5,  N'Verwarnung', '2026-07-15 11:30:00', NULL,                  N'Zeitslot ohne Absage nicht wahrgenommen.'),
    (2, 5,  6,  N'Sperre',     '2026-08-03 08:00:00', '2026-08-17 08:00:00', N'Wiederholter Versand von Werbenachrichten.'),
    (1, 4,  4,  N'Sperre',     '2026-09-06 12:00:00', '2026-10-06 12:00:00', N'Gewerbliches Anbieten von Büchern.'),
    (2, 10, 5,  N'Sperre',     '2026-10-09 09:30:00', '2026-10-23 09:30:00', N'Erneut Termin verpasst nach Verwarnung.'),
    (1, 6,  2,  N'Verwarnung', '2026-08-22 15:00:00', NULL,                  N'Hinweis auf pünktliche Rückgabe.'),
    (2, 8,  8,  N'Verwarnung', '2026-10-03 10:15:00', NULL,                  N'Beschädigung eines ausgeliehenen Buches.'),
    (1, 7,  9,  N'Verwarnung', '2026-09-19 16:45:00', NULL,                  N'Hinweis auf ehrliche Bewertungen.'),
    (2, 9,  7,  N'Ausschluss', '2026-10-12 13:00:00', NULL,                  N'Angebot rechtswidriger Inhalte.');
GO

-- ============================================================
-- Kontrolle: Anzahl der Datensätze je Tabelle
-- ============================================================
SELECT t.name AS Tabelle, SUM(p.rows) AS Datensaetze
FROM sys.tables t
JOIN sys.partitions p ON p.object_id = t.object_id AND p.index_id IN (0, 1)
GROUP BY t.name
ORDER BY t.name;
GO
