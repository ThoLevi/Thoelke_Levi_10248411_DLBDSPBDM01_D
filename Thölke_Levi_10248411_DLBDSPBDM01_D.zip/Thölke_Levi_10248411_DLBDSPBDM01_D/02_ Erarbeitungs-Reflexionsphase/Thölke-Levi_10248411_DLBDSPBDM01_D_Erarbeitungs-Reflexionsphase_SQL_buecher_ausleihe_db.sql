﻿-- =====================================================================
--  Buchverleih / Buchtausch-App – Erstellung der Datenbank
--  DBMS: Microsoft SQL Server, ausführbar in SQL Server Management Studio
--  Grundlage: ER-Diagramm und Datenwörterbuch (20 Tabellen)
-- =====================================================================

-- 1. Datenbank anlegen und verbinden
CREATE DATABASE buecher_ausleihe_db;
GO

USE buecher_ausleihe_db;
GO

-- 2. Adressen und Koordinaten
-- ============================================================
-- TABELLE: Ort
--
-- Speichert Orte (Postleitzahl, Stadt, Land). Jede Kombination ist eindeutig.
--
-- Beziehungen:
-- Ein Ort kann mehrere Adressen enthalten (1:n).
-- Jede Adresse verweist über OrtID auf genau einen Ort.
-- ============================================================
CREATE TABLE Ort (
    OrtID        INT IDENTITY(1,1) PRIMARY KEY,
    Postleitzahl NVARCHAR(10)  NOT NULL,
    Stadt        NVARCHAR(100) NOT NULL,
    Land         CHAR(2)       NOT NULL CONSTRAINT df_ort_land DEFAULT 'DE',
    CONSTRAINT uq_ort UNIQUE (Postleitzahl, Stadt, Land)
);
GO

-- ============================================================
-- TABELLE: Adresse
--
-- Speichert Straße, Hausnummer und die Koordinaten (Breiten- und Längengrad)
-- für die Umkreissuche.
--
-- Beziehungen:
-- Jede Adresse liegt in genau einem Ort (n:1).
-- Eine Adresse kann mehreren Benutzern zugeordnet sein (1:n).
-- An einer Adresse können mehrere Abholorte liegen (1:n).
-- ============================================================
CREATE TABLE Adresse (
    AdresseID   INT IDENTITY(1,1) PRIMARY KEY,
    OrtID       INT           NOT NULL REFERENCES Ort (OrtID) ON DELETE NO ACTION,
    Strasse     NVARCHAR(150) NOT NULL,
    Hausnummer  NVARCHAR(10)  NOT NULL,
    -- Koordinaten für die Umkreissuche (z. B. 48.138631 / 11.573694 für die Frauenkirche in München)
    Breitengrad DECIMAL(9,6)  NOT NULL CHECK (Breitengrad BETWEEN -90 AND 90),
    Laengengrad DECIMAL(9,6)  NOT NULL CHECK (Laengengrad BETWEEN -180 AND 180)
);
GO

-- 3. Benutzer
-- ============================================================
-- TABELLE: Benutzer
--
-- Speichert die registrierten Benutzer. IsAdmin kennzeichnet Administratoren.
--
-- Beziehungen:
-- Jeder Benutzer besitzt genau eine Adresse (n:1).
-- Ein Benutzer kann mehrere Exemplare besitzen (1:n).
-- Ein Benutzer kann mehrere Ausleihen als Ausleiher haben (1:n).
-- Ein Benutzer kann mehrere Abholorte anbieten (1:n).
-- Ein Benutzer kann mehrere Buchbewertungen abgeben (1:n).
-- Zusätzlich ist der Benutzer an den ternären Beziehungen Benutzerbewertung,
-- Meldung und Sanktion beteiligt (siehe dort).
-- ============================================================
CREATE TABLE Benutzer (
    BenutzerID    INT IDENTITY(1,1) PRIMARY KEY,
    Name          NVARCHAR(100) NOT NULL,
    Email         NVARCHAR(255) NOT NULL UNIQUE CHECK (Email LIKE '%_@_%'),
    Telefonnummer NVARCHAR(30)  NULL,
    AdresseID     INT           NOT NULL REFERENCES Adresse (AdresseID) ON DELETE NO ACTION,
    IsAdmin       BIT           NOT NULL CONSTRAINT df_benutzer_isadmin DEFAULT 0,
    RegistriertAm DATETIME2(0)  NOT NULL CONSTRAINT df_benutzer_registriert DEFAULT SYSDATETIME()
);
GO

-- 4. Daten zu Büchern
-- ============================================================
-- TABELLE: Genre
--
-- Speichert die literarischen Genres der Bücher.
--
-- Beziehungen:
-- Ein Genre kann mehreren Büchern zugeordnet sein (1:n).
-- Jedes Buch verweist auf genau ein Genre.
-- ============================================================
CREATE TABLE Genre (
    GenreID INT IDENTITY(1,1) PRIMARY KEY,
    Name    NVARCHAR(100) NOT NULL UNIQUE
);

-- ============================================================
-- TABELLE: Verlag
--
-- Speichert Verlage, die Bücher veröffentlichen.
--
-- Beziehungen:
-- Ein Verlag kann mehrere Bücher veröffentlichen (1:n).
-- Jedes Buch verweist auf genau einen Verlag.
-- ============================================================
CREATE TABLE Verlag (
    VerlagID INT IDENTITY(1,1) PRIMARY KEY,
    Name     NVARCHAR(150) NOT NULL UNIQUE
);

-- ============================================================
-- TABELLE: Sprache
--
-- Speichert die Sprachen, in denen Bücher vorliegen können.
--
-- Beziehungen:
-- Eine Sprache kann mehreren Büchern zugeordnet sein (1:n).
-- Jedes Buch verweist auf genau eine Sprache.
-- ============================================================
CREATE TABLE Sprache (
    SpracheID INT IDENTITY(1,1) PRIMARY KEY,
    Name      NVARCHAR(50) NOT NULL UNIQUE
);

-- ============================================================
-- TABELLE: Autor
--
-- Speichert Autoren von Büchern.
--
-- Beziehungen:
-- Ein Autor kann mehrere Bücher geschrieben haben und ein Buch
-- kann mehrere Autoren besitzen. Die n:m-Beziehung wird über
-- die Zwischentabelle BuchAutor aufgelöst.
-- ============================================================
CREATE TABLE Autor (
    AutorID INT IDENTITY(1,1) PRIMARY KEY,
    Name    NVARCHAR(150) NOT NULL
);
GO

-- ============================================================
-- TABELLE: Buch
--
-- Speichert die bibliografischen Stammdaten eines Buches.
--
-- Beziehungen:
-- Jedes Buch hat genau einen Verlag, ein Genre und eine Sprache (n:1).
-- Ein Buch kann mehrere Autoren besitzen (n:m über BuchAutor).
-- Ein Buch kann mehrere physische Exemplare besitzen (1:n).
-- Ein Buch kann mehrere Bewertungen erhalten (1:n).
-- ============================================================
CREATE TABLE Buch (
    BuchID           INT IDENTITY(1,1) PRIMARY KEY,
    Titel            NVARCHAR(255) NOT NULL,
    VerlagID         INT           NOT NULL REFERENCES Verlag (VerlagID)   ON DELETE NO ACTION,
    GenreID          INT           NOT NULL REFERENCES Genre (GenreID)     ON DELETE NO ACTION,
    SpracheID        INT           NOT NULL REFERENCES Sprache (SpracheID) ON DELETE NO ACTION,
    -- Erscheinungsjahr zwischen 1450 und dem aktuellen Jahr
    Erscheinungsjahr SMALLINT      NOT NULL CHECK (Erscheinungsjahr BETWEEN 1450 AND YEAR(GETDATE()))
);
GO

-- ============================================================
-- TABELLE: BuchAutor
--
-- Verknüpft Bücher und Autoren und löst damit die n:m-Beziehung
-- zwischen beiden Tabellen auf.
--
-- Beziehungen:
-- Ein Buch kann mehreren Autoren zugeordnet sein (1:n).
-- Ein Autor kann mehreren Büchern zugeordnet sein (1:n).
-- Jede Kombination aus Buch und Autor darf nur einmal vorkommen (PK).
-- ============================================================
CREATE TABLE BuchAutor (
    BuchID  INT NOT NULL REFERENCES Buch (BuchID)   ON DELETE CASCADE,
    AutorID INT NOT NULL REFERENCES Autor (AutorID) ON DELETE CASCADE,
    CONSTRAINT pk_buchautor PRIMARY KEY (BuchID, AutorID)
);

-- ============================================================
-- TABELLE: Buchbewertung
--
-- Speichert Bewertungen (1 bis 5 Sterne), die Benutzer zu Büchern abgeben.
--
-- Beziehungen:
-- Ein Benutzer kann mehrere Buchbewertungen abgeben (1:n).
-- Ein Buch kann mehrere Bewertungen erhalten (1:n).
-- Jede Buchbewertung gehört zu genau einem Benutzer und einem Buch;
-- ein Benutzer bewertet jedes Buch höchstens einmal (UNIQUE).
-- ============================================================
CREATE TABLE Buchbewertung (
    BuchbewertungID INT IDENTITY(1,1) PRIMARY KEY,
    BenutzerID      INT      NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE CASCADE,
    BuchID          INT      NOT NULL REFERENCES Buch (BuchID)         ON DELETE CASCADE,
    Sterne          TINYINT  NOT NULL CHECK (Sterne BETWEEN 1 AND 5),
    Datum           DATE     NOT NULL CONSTRAINT df_buchbewertung_datum DEFAULT CAST(GETDATE() AS DATE),
    CONSTRAINT uq_buchbewertung UNIQUE (BenutzerID, BuchID)
);
GO

-- 5. Bestand
-- ============================================================
-- TABELLE: Exemplar
--
-- Speichert einzelne physische Exemplare eines Buches.
--
-- Beziehungen:
-- Ein Buch kann mehrere Exemplare besitzen (1:n).
-- Jedes Exemplar gehört genau zu einem Buch.
-- Ein Benutzer kann mehrere Exemplare besitzen (1:n).
-- Jedes Exemplar hat genau einen Besitzer (BesitzerID). Der Besitzer ist
-- zugleich der Verleiher einer Ausleihe.
-- Ein Exemplar kann im Laufe der Zeit mehrfach ausgeliehen werden (1:n).
-- ============================================================
CREATE TABLE Exemplar (
    ExemplarID    INT IDENTITY(1,1) PRIMARY KEY,
    BuchID        INT          NOT NULL REFERENCES Buch (BuchID)         ON DELETE NO ACTION,
    BesitzerID    INT          NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    Zustand       NVARCHAR(30) NOT NULL
                  CHECK (Zustand IN (N'neu', N'sehr gut', N'gut', N'gebraucht', N'stark gebraucht')),
    IstAusleihbar BIT          NOT NULL CONSTRAINT df_exemplar_ausleihbar DEFAULT 1
);
GO

-- 6. Übergabe: Versand, Abholorte, Zeitslots
-- ============================================================
-- TABELLE: Versandoption
--
-- Speichert Versandoptionen (Anbieter, Preis, Lieferzeit) für den Postversand.
--
-- Beziehungen:
-- Eine Versandoption kann bei mehreren Ausleihen gewählt werden (1:n).
-- Jede Ausleihe mit Versand verweist auf genau eine Versandoption
-- (0..1, nur bei Uebergabeart = Versand).
-- ============================================================
CREATE TABLE Versandoption (
    VersandoptionID INT IDENTITY(1,1) PRIMARY KEY,
    Anbieter        NVARCHAR(50)  NOT NULL,
    Bezeichnung     NVARCHAR(100) NOT NULL,
    Preis           DECIMAL(6,2)  NOT NULL CHECK (Preis >= 0),
    LieferzeitTage  INT           NOT NULL CHECK (LieferzeitTage > 0)
);

-- ============================================================
-- TABELLE: Abholort
--
-- Speichert Orte, an denen ein Benutzer seine Bücher zur Abholung anbietet.
--
-- Beziehungen:
-- Ein Benutzer kann mehrere Abholorte anbieten (1:n).
-- Jeder Abholort liegt an genau einer Adresse (n:1).
-- Ein Abholort kann mehrere Zeitslots haben (1:n).
-- ============================================================
CREATE TABLE Abholort (
    AbholortID  INT IDENTITY(1,1) PRIMARY KEY,
    BenutzerID  INT           NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE CASCADE,
    AdresseID   INT           NOT NULL REFERENCES Adresse (AdresseID)   ON DELETE NO ACTION,
    Bezeichnung NVARCHAR(100) NOT NULL,
    Hinweis     NVARCHAR(255) NULL
);
GO

-- ============================================================
-- TABELLE: Zeitslot
--
-- Speichert buchbare Zeitfenster (Beginn, Ende) an einem Abholort.
--
-- Beziehungen:
-- Jeder Zeitslot gehört zu genau einem Abholort (n:1).
-- Ein Zeitslot wird höchstens für eine Abholung bzw. eine Rückgabe
-- genutzt (0..1 zu 0..1, gefilterter Unique-Index in Ausleihe).
-- ============================================================
CREATE TABLE Zeitslot (
    ZeitslotID INT IDENTITY(1,1) PRIMARY KEY,
    AbholortID INT          NOT NULL REFERENCES Abholort (AbholortID) ON DELETE CASCADE,
    Beginn     DATETIME2(0) NOT NULL,
    Ende       DATETIME2(0) NOT NULL,
    CONSTRAINT chk_zeitslot CHECK (Ende > Beginn)
);
GO

-- 7. Ausleihprozess
-- ============================================================
-- TABELLE: Ausleihe
--
-- Speichert Ausleihvorgänge einzelner Exemplare zwischen Benutzern
-- inklusive Status, Rückgabedaten und Übergabeart.
--
-- Beziehungen:
-- Ein Benutzer kann mehrere Exemplare ausleihen (1:n).
-- Ein Exemplar kann im Laufe der Zeit mehrfach ausgeliehen werden (1:n).
-- Der Verleiher ergibt sich aus Exemplar.BesitzerID (kein eigener FK).
-- Eine Ausleihe nutzt höchstens einen Abhol- und einen Rückgabe-Zeitslot (n:0..1).
-- Eine Ausleihe nutzt höchstens eine Versandoption (n:0..1).
-- Eine Ausleihe kann mehrere Verlängerungsanfragen haben (1:n).
-- Eine Ausleihe kann mehrere Benutzerbewertungen erhalten (1:n).
-- ============================================================
CREATE TABLE Ausleihe (
    AusleiheID                   INT IDENTITY(1,1) PRIMARY KEY,
    AusleiherID                  INT          NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    ExemplarID                   INT          NOT NULL REFERENCES Exemplar (ExemplarID) ON DELETE NO ACTION,
    AngefragtAm                  DATETIME2(0) NOT NULL CONSTRAINT df_ausleihe_angefragt DEFAULT SYSDATETIME(),
    Startdatum                   DATE         NOT NULL,
    GeplantesRueckgabedatum      DATE         NOT NULL,
    TatsaechlichesRueckgabedatum DATE         NULL,
    Status                       NVARCHAR(20) NOT NULL CONSTRAINT df_ausleihe_status DEFAULT N'angefragt'
                                 CHECK (Status IN (N'angefragt', N'bestaetigt', N'ausgeliehen', N'zurueckgegeben', N'abgelehnt', N'storniert')),
    Uebergabeart                 NVARCHAR(10) NOT NULL CHECK (Uebergabeart IN (N'Abholung', N'Versand')),
    AbholZeitslotID              INT          NULL REFERENCES Zeitslot (ZeitslotID) ON DELETE NO ACTION,
    RueckgabeZeitslotID          INT          NULL REFERENCES Zeitslot (ZeitslotID) ON DELETE NO ACTION,
    VersandoptionID              INT          NULL REFERENCES Versandoption (VersandoptionID) ON DELETE NO ACTION,
    Sendungsnummer               NVARCHAR(50) NULL,
    CONSTRAINT chk_rueckgabe_geplant      CHECK (GeplantesRueckgabedatum >= Startdatum),
    CONSTRAINT chk_rueckgabe_tatsaechlich CHECK (TatsaechlichesRueckgabedatum IS NULL OR TatsaechlichesRueckgabedatum >= Startdatum),
    CONSTRAINT chk_versand  CHECK (Uebergabeart <> N'Versand'  OR VersandoptionID IS NOT NULL),
    CONSTRAINT chk_abholung CHECK (Uebergabeart <> N'Abholung' OR AbholZeitslotID IS NOT NULL)
);
GO

-- Ein Zeitslot gehört höchstens zu einer Übergabe. UNIQUE-Constraints würden in
-- SQL Server nur einen einzigen NULL-Wert zulassen, daher gefilterte Unique-Indizes.
CREATE UNIQUE INDEX uq_ausleihe_abholslot    ON Ausleihe (AbholZeitslotID)     WHERE AbholZeitslotID IS NOT NULL;
CREATE UNIQUE INDEX uq_ausleihe_rueckgabeslot ON Ausleihe (RueckgabeZeitslotID) WHERE RueckgabeZeitslotID IS NOT NULL;
GO

-- ============================================================
-- TABELLE: Verlaengerungsanfrage
--
-- Speichert Anfragen, eine laufende Ausleihe zu verlängern.
--
-- Beziehungen:
-- Eine Ausleihe kann mehrere Verlängerungsanfragen haben (1:n).
-- Jede Verlängerungsanfrage gehört zu genau einer Ausleihe.
-- ============================================================
CREATE TABLE Verlaengerungsanfrage (
    VerlaengerungID     INT IDENTITY(1,1) PRIMARY KEY,
    AusleiheID          INT          NOT NULL REFERENCES Ausleihe (AusleiheID) ON DELETE CASCADE,
    BeantragtAm         DATETIME2(0) NOT NULL CONSTRAINT df_verlaengerung_beantragt DEFAULT SYSDATETIME(),
    NeuesRueckgabedatum DATE         NOT NULL,
    Status              NVARCHAR(20) NOT NULL CONSTRAINT df_verlaengerung_status DEFAULT N'offen'
                        CHECK (Status IN (N'offen', N'angenommen', N'abgelehnt'))
);
GO

-- 8. Community und Moderation (ternäre Beziehungen)
-- Hinweis: SQL Server erlaubt pro Tabelle nur einen kaskadierenden Pfad zur
-- selben Elterntabelle. Bei zwei Fremdschlüsseln auf Benutzer steht daher
-- mindestens einer auf NO ACTION.

-- ============================================================
-- TABELLE: Benutzerbewertung
--
-- Speichert Bewertungen, die sich Benutzer nach einer Ausleihe gegenseitig geben.
--
-- Beziehungen:
-- Ternäre Beziehung: Bewerter × Bewerteter × Ausleihe.
-- Ein Benutzer kann als Bewerter mehrere Bewertungen abgeben (1:n).
-- Ein Benutzer kann als Bewerteter mehrere Bewertungen erhalten (1:n).
-- Eine Ausleihe kann mehrere Bewertungen haben (1:n), pro Richtung
-- aber höchstens eine (UNIQUE). Keine Selbstbewertung (CHECK).
-- ============================================================
CREATE TABLE Benutzerbewertung (
    BenutzerbewertungID INT IDENTITY(1,1) PRIMARY KEY,
    BewerterID          INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    BewerteterID        INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    AusleiheID          INT            NOT NULL REFERENCES Ausleihe (AusleiheID) ON DELETE CASCADE,
    Sterne              TINYINT        NOT NULL CHECK (Sterne BETWEEN 1 AND 5),
    Kommentar           NVARCHAR(1000) NULL,
    Datum               DATE           NOT NULL CONSTRAINT df_benutzerbewertung_datum DEFAULT CAST(GETDATE() AS DATE),
    CONSTRAINT chk_keine_selbstbewertung CHECK (BewerterID <> BewerteterID),
    CONSTRAINT uq_benutzerbewertung UNIQUE (BewerterID, BewerteterID, AusleiheID)
);

-- ============================================================
-- TABELLE: Regel
--
-- Speichert die Plattformregeln, auf die sich Meldungen und Sanktionen beziehen.
--
-- Beziehungen:
-- Eine Regel kann in mehreren Meldungen genannt werden (1:n).
-- Eine Regel kann Grundlage mehrerer Sanktionen sein (1:n).
-- ============================================================
CREATE TABLE Regel (
    RegelID      INT IDENTITY(1,1) PRIMARY KEY,
    Bezeichnung  NVARCHAR(100)  NOT NULL UNIQUE,
    Beschreibung NVARCHAR(1000) NOT NULL
);
GO

-- ============================================================
-- TABELLE: Meldung
--
-- Speichert Meldungen von Benutzern über Regelverstöße anderer Benutzer.
--
-- Beziehungen:
-- Ternäre Beziehung: Melder × Gemeldeter × Regel.
-- Ein Benutzer kann mehrere Meldungen erstellen (1:n).
-- Ein Benutzer kann mehrfach gemeldet werden (1:n).
-- Jede Meldung bezieht sich auf genau eine Regel (n:1).
-- Keine Selbstmeldung (CHECK).
-- ============================================================
CREATE TABLE Meldung (
    MeldungID    INT IDENTITY(1,1) PRIMARY KEY,
    MelderID     INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    GemeldeterID INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    RegelID      INT            NOT NULL REFERENCES Regel (RegelID)       ON DELETE NO ACTION,
    Beschreibung NVARCHAR(1000) NOT NULL,
    GemeldetAm   DATETIME2(0)   NOT NULL CONSTRAINT df_meldung_gemeldet DEFAULT SYSDATETIME(),
    Status       NVARCHAR(20)   NOT NULL CONSTRAINT df_meldung_status DEFAULT N'offen'
                 CHECK (Status IN (N'offen', N'geprueft', N'verworfen')),
    CONSTRAINT chk_keine_selbstmeldung CHECK (MelderID <> GemeldeterID)
);

-- ============================================================
-- TABELLE: Sanktion
--
-- Speichert Sanktionen (Verwarnung, Sperre, Ausschluss), die ein Admin verhängt.
--
-- Beziehungen:
-- Ternäre Beziehung: Admin × Benutzer × Regel.
-- Ein Admin kann mehrere Sanktionen verhängen (1:n).
-- Ein Benutzer kann mehrere Sanktionen erhalten (1:n).
-- Jede Sanktion bezieht sich auf genau eine Regel (n:1).
-- Dass der verhängende Benutzer Admin ist, prüft die Anwendung.
-- ============================================================
CREATE TABLE Sanktion (
    SanktionID  INT IDENTITY(1,1) PRIMARY KEY,
    AdminID     INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE NO ACTION,
    BenutzerID  INT            NOT NULL REFERENCES Benutzer (BenutzerID) ON DELETE CASCADE,
    RegelID     INT            NOT NULL REFERENCES Regel (RegelID)       ON DELETE NO ACTION,
    Art         NVARCHAR(20)   NOT NULL CHECK (Art IN (N'Verwarnung', N'Sperre', N'Ausschluss')),
    Beginn      DATETIME2(0)   NOT NULL CONSTRAINT df_sanktion_beginn DEFAULT SYSDATETIME(),
    Ende        DATETIME2(0)   NULL,
    Begruendung NVARCHAR(1000) NOT NULL,
    CONSTRAINT chk_sanktion_zeitraum   CHECK (Ende IS NULL OR Ende > Beginn),
    CONSTRAINT chk_keine_selbstsanktion CHECK (AdminID <> BenutzerID)
);
GO
