﻿-- =====================================================================
--  Buchverleih / Buchtausch-App – Metadaten der Datenbank
--  DBMS: Microsoft SQL Server, ausführbar in SQL Server Management Studio
--  Voraussetzung: buecher_ausleihe_db_mssql.sql und beispieldaten_mssql.sql
-- =====================================================================
USE buecher_ausleihe_db;
GO

-- ============================================================
-- 1. Anzahl der Tabellen, Spalten und Constraints
-- ============================================================
SELECT (SELECT COUNT(*) FROM sys.tables)                                AS Tabellen,
       (SELECT COUNT(*) FROM sys.columns c
          JOIN sys.tables t ON t.object_id = c.object_id)               AS Spalten,
       (SELECT COUNT(*) FROM sys.key_constraints WHERE type = 'PK')     AS PrimaryKeys,
       (SELECT COUNT(*) FROM sys.foreign_keys)                          AS ForeignKeys,
       (SELECT COUNT(*) FROM sys.key_constraints WHERE type = 'UQ')     AS UniqueConstraints,
       (SELECT COUNT(*) FROM sys.check_constraints)                     AS CheckConstraints,
       (SELECT COUNT(*) FROM sys.default_constraints)                   AS DefaultConstraints;
GO

-- ============================================================
-- 2. Einträge, Spalten und Speicherplatz je Tabelle
-- ============================================================
SELECT t.name                                                        AS Tabelle,
       (SELECT COUNT(*) FROM sys.columns c WHERE c.object_id = t.object_id) AS Spalten,
       SUM(CASE WHEN s.index_id IN (0, 1) THEN s.row_count END)      AS Eintraege,
       SUM(s.used_page_count) * 8                                    AS BelegtKB,
       SUM(s.reserved_page_count) * 8                                AS ReserviertKB
FROM sys.tables t
JOIN sys.dm_db_partition_stats s ON s.object_id = t.object_id
GROUP BY t.name, t.object_id
ORDER BY t.name;
GO

-- ============================================================
-- 3. Summe über alle Tabellen
-- ============================================================
SELECT COUNT(DISTINCT t.object_id)                              AS Tabellen,
       SUM(CASE WHEN s.index_id IN (0, 1) THEN s.row_count END) AS EintraegeGesamt,
       SUM(s.used_page_count) * 8                               AS BelegtKB,
       SUM(s.reserved_page_count) * 8                           AS ReserviertKB
FROM sys.tables t
JOIN sys.dm_db_partition_stats s ON s.object_id = t.object_id;
GO

-- ============================================================
-- 4. Größe der Datenbank (Daten- und Protokolldatei)
-- ============================================================
SELECT name                       AS Datei,
       type_desc                  AS Typ,
       CAST(size * 8 / 1024.0 AS DECIMAL(10, 2)) AS GroesseMB
FROM sys.database_files;

EXEC sp_spaceused;
GO
