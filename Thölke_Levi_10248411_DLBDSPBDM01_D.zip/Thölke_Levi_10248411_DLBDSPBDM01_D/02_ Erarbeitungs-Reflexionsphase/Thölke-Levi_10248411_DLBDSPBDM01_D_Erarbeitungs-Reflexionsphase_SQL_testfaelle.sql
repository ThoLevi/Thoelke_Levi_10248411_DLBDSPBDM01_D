﻿-- =====================================================================
--  Buchverleih / Buchtausch-App – einfache Testfälle (einer je Tabelle)
--  DBMS: Microsoft SQL Server (T-SQL), ausführbar in SQL Server Management Studio
--  Voraussetzung: Thölke-Levi_10248411_DLBDSPBDM01_D_P2_SQL_buecher_ausleihe_db.sql und Thölke-Levi_10248411_DLBDSPBDM01_D_P2_SQL_beispieldaten.sql
--  wurden zuvor ausgeführt. Die Abfragen ändern keine Daten.
-- =====================================================================
USE buecher_ausleihe_db;
GO

-- ============================================================
-- TESTFALL 1: Ort
-- Testziel: Alle Orte in München anzeigen.
-- Erwartetes Ergebnis: 10 Zeilen (alle Orte liegen in München).
-- ============================================================
SELECT * FROM Ort WHERE Stadt = N'München';
GO

-- ============================================================
-- TESTFALL 2: Adresse
-- Testziel: Adressen zu einem bestimmten Ort (OrtID 1) anzeigen.
-- Erwartetes Ergebnis: 1 Zeile: Leopoldstraße 137 mit Breitengrad 48.170200 und Längengrad 11.586500.
-- ============================================================
SELECT * FROM Adresse WHERE OrtID = 1;
GO

-- ============================================================
-- TESTFALL 3: Benutzer
-- Testziel: Alle Administratoren anzeigen.
-- Erwartetes Ergebnis: 2 Zeilen: Max Mustermann und Anna Schmidt.
-- ============================================================
SELECT Name, Email FROM Benutzer WHERE IsAdmin = 1;
GO

-- ============================================================
-- TESTFALL 4: Genre
-- Testziel: Alle Genres alphabetisch anzeigen.
-- Erwartetes Ergebnis: 10 Zeilen, beginnend mit Biografie.
-- ============================================================
SELECT * FROM Genre ORDER BY Name;
GO

-- ============================================================
-- TESTFALL 5: Verlag
-- Testziel: Alle Verlage anzeigen, deren Name „Verlag“ enthält.
-- Erwartetes Ergebnis: 7 Zeilen (z. B. Penguin Verlag, Suhrkamp Verlag).
-- ============================================================
SELECT * FROM Verlag WHERE Name LIKE N'%Verlag%';
GO

-- ============================================================
-- TESTFALL 6: Sprache
-- Testziel: Alle Sprachen anzeigen.
-- Erwartetes Ergebnis: 10 Zeilen, von Deutsch bis Chinesisch.
-- ============================================================
SELECT * FROM Sprache;
GO

-- ============================================================
-- TESTFALL 7: Autor
-- Testziel: Autoren suchen, deren Name „Mann“ enthält.
-- Erwartetes Ergebnis: 2 Zeilen: Thomas Mann und Ingeborg Bachmann.
-- ============================================================
SELECT * FROM Autor WHERE Name LIKE N'%Mann%';
GO

-- ============================================================
-- TESTFALL 8: Buch
-- Testziel: Alle Bücher anzeigen, die vor 1900 erschienen sind.
-- Erwartetes Ergebnis: 2 Zeilen: Faust (1808) und Die Räuber (1781).
-- ============================================================
SELECT Titel, Erscheinungsjahr FROM Buch WHERE Erscheinungsjahr < 1900;
GO

-- ============================================================
-- TESTFALL 9: BuchAutor
-- Testziel: Den Autor zu Buch 3 über die Zwischentabelle ermitteln.
-- Erwartetes Ergebnis: 1 Zeile: BuchID 3, Thomas Mann.
-- ============================================================
SELECT ba.BuchID, a.Name AS Autor
FROM BuchAutor ba
JOIN Autor a ON a.AutorID = ba.AutorID
WHERE ba.BuchID = 3;
GO

-- ============================================================
-- TESTFALL 10: Buchbewertung
-- Testziel: Alle Bewertungen mit 5 Sternen anzeigen.
-- Erwartetes Ergebnis: 3 Zeilen.
-- ============================================================
SELECT * FROM Buchbewertung WHERE Sterne = 5;
GO

-- ============================================================
-- TESTFALL 11: Exemplar
-- Testziel: Alle ausleihbaren Exemplare anzeigen.
-- Erwartetes Ergebnis: 9 Zeilen (nur Exemplar 10 ist nicht ausleihbar).
-- ============================================================
SELECT * FROM Exemplar WHERE IstAusleihbar = 1;
GO

-- ============================================================
-- TESTFALL 12: Versandoption
-- Testziel: Alle Versandoptionen unter 4 Euro anzeigen.
-- Erwartetes Ergebnis: 4 Zeilen (Preise 1.95, 2.70, 3.79 und 3.99).
-- ============================================================
SELECT * FROM Versandoption WHERE Preis < 4.00;
GO

-- ============================================================
-- TESTFALL 13: Abholort
-- Testziel: Alle Abholorte ohne Hinweis anzeigen.
-- Erwartetes Ergebnis: 4 Zeilen.
-- ============================================================
SELECT * FROM Abholort WHERE Hinweis IS NULL;
GO

-- ============================================================
-- TESTFALL 14: Zeitslot
-- Testziel: Alle Zeitslots am Abholort 1 anzeigen.
-- Erwartetes Ergebnis: 2 Zeilen (eine Abholung am 03.08. und eine Rückgabe am 16.08.).
-- ============================================================
SELECT * FROM Zeitslot WHERE AbholortID = 1;
GO

-- ============================================================
-- TESTFALL 15: Ausleihe
-- Testziel: Alle Ausleihen anzeigen, die gerade ausgeliehen sind.
-- Erwartetes Ergebnis: 3 Zeilen (Ausleihen 4, 5 und 8).
-- ============================================================
SELECT AusleiheID, ExemplarID, Startdatum, GeplantesRueckgabedatum, Status FROM Ausleihe WHERE Status = N'ausgeliehen';
GO

-- ============================================================
-- TESTFALL 16: Verlaengerungsanfrage
-- Testziel: Alle offenen Verlängerungsanfragen anzeigen.
-- Erwartetes Ergebnis: 4 Zeilen.
-- ============================================================
SELECT * FROM Verlaengerungsanfrage WHERE Status = N'offen';
GO

-- ============================================================
-- TESTFALL 17: Benutzerbewertung
-- Testziel: Alle Bewertungen zur Ausleihe 1 anzeigen.
-- Erwartetes Ergebnis: 2 Zeilen (Ausleiher und Verleiher bewerten sich gegenseitig).
-- ============================================================
SELECT * FROM Benutzerbewertung WHERE AusleiheID = 1;
GO

-- ============================================================
-- TESTFALL 18: Regel
-- Testziel: Alle Plattformregeln alphabetisch anzeigen.
-- Erwartetes Ergebnis: 10 Zeilen.
-- ============================================================
SELECT * FROM Regel ORDER BY Bezeichnung;
GO

-- ============================================================
-- TESTFALL 19: Meldung
-- Testziel: Alle offenen Meldungen anzeigen.
-- Erwartetes Ergebnis: 3 Zeilen.
-- ============================================================
SELECT * FROM Meldung WHERE Status = N'offen';
GO

-- ============================================================
-- TESTFALL 20: Sanktion
-- Testziel: Alle Sperren anzeigen.
-- Erwartetes Ergebnis: 3 Zeilen.
-- ============================================================
SELECT * FROM Sanktion WHERE Art = N'Sperre';
GO
