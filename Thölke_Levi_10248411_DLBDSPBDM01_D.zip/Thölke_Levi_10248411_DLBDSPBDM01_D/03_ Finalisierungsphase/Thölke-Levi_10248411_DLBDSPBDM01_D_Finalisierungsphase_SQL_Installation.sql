-- =====================================================================
--  Buchverleih / Buchtausch-App – Installation
--  DBMS: Microsoft SQL Server 2022, ausführbar in SQL Server Management Studio
--
--  Anleitung:
--  1. Alle SQL-Dateien in einen Ordner legen und diese Datei in SSMS öffnen.
--  2. Menü „Abfrage“ > „SQLCMD-Modus“ aktivieren.
--  3. Unten den Pfad zu diesem Ordner eintragen.
--  4. Mit F5 ausführen.
-- =====================================================================

:setvar SkriptPfad "C:\Thölke_Levi_10248411_DLBDSPBDM01_D\02_ Erarbeitungs-Reflexionsphase"

-- Vorhandene Datenbank entfernen, damit die Installation wiederholt werden kann
USE master;
DROP DATABASE IF EXISTS buecher_ausleihe_db;
GO

-- 1. Datenbank mit allen 20 Tabellen anlegen
:r $(SkriptPfad)\Thölke-Levi_10248411_DLBDSPBDM01_D_Erarbeitungs-Reflexionsphase_SQL_buecher_ausleihe_db.sql

-- 2. Beispieldaten einfügen
:r $(SkriptPfad)\Thölke-Levi_10248411_DLBDSPBDM01_D_Erarbeitungs-Reflexionsphase_SQL_beispieldaten.sql

-- 3. Testfälle ausführen
:r $(SkriptPfad)\Thölke-Levi_10248411_DLBDSPBDM01_D_Erarbeitungs-Reflexionsphase_SQL_testfaelle.sql

-- 4. Metadaten ausgeben
:r $(SkriptPfad)\Thölke-Levi_10248411_DLBDSPBDM01_D_Erarbeitungs-Reflexionsphase_SQL_metadaten.sql
